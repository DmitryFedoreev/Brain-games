from brain_games.engine import play_game
from brain_games.games.prime import game


def main():
    play_game(game)


if __name__ == "__main__":
    main()
