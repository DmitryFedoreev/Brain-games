from brain_games.common import play_game
from brain_games.games.calc import game


def main():
    play_game(game)


if __name__ == "__main__":
    main()
