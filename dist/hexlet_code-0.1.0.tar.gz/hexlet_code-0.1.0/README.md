### Hexlet tests and linter status/Maintainability Badge:
[![Actions Status](https://github.com/DmitryFedoreev/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DmitryFedoreev/python-project-49/actions)
<a href="https://codeclimate.com/github/DmitryFedoreev/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/6c77d38fd5d0fc1909a1/maintainability" /></a>


#### Video demonstration of the game “Parity Check”
[![asciicast](https://asciinema.org/a/cLf3y7g8xYzLJeam8KAISlEBk.svg)](https://asciinema.org/a/cLf3y7g8xYzLJeam8KAISlEBk)

