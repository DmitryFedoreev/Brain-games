def main():
    print('poetry run python -m brain_games.scripts.brain_games\nWelcome to the Brain Games!')
